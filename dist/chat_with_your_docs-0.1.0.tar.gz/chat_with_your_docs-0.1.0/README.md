### Chat with your docs!!! 

Have you ever wondered, if there's a way to summarise your docs or there's a way to get answers on the knowledge base that is not answerable by chat assistants? We've covered that problem for you! with Chat with docs, you can just upload your document or provide a website link. Our assistant will be able to answers based on the provided documents in no time. 

Don't forget to star our repository if liked it :) .